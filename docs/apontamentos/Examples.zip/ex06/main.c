/* main.c */ 
#include "hello.h"

int main(void)  
     {
	hello();
	return 0; 
	 } 
