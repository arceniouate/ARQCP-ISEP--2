/* hello.h */ 

#ifndef HELLO_H

#define HELLO_H 
void hello(void);   
#endif 
