/*  hello.c */ 
#include <stdio.h>

#include "hello.h"

void hello(void)  
     {
	printf("Hello, world\n");
	 } 


