/*  ex09/count.c */  
#include <stdio.h>

extern int      students, teachers;
extern int      yylex(void);

int main(int argc, char **argv)
{
	yylex();
	printf("Students: %d Teachers: %d \n", students, teachers);
	return(0);
}
