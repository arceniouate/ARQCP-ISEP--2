/* hello.h */ 
void hello(void);   
