#include <stdio.h>
#include <termios.h>
#include <unistd.h>

/*  mygetch reads a char without echo */ 
 int mygetch( ) {
    struct termios oldt, newt;
    int ch;    
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~( ICANON | ECHO );
    tcsetattr( STDIN_FILENO, TCSANOW, &newt );
    ch = getchar();
    tcsetattr( STDIN_FILENO, TCSANOW, &oldt );
    return (ch);
 }

int main()
{
char c;
   printf("Enter any characters, terminate program with X\n");

   do {
      c = mygetch();                /* get a character */
      putchar(c);                  /* display the hit key */
   } while (c != 'X');

   printf("\nEnd of program.\n");
   return(0); 
}
