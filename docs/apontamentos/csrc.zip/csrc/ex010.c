#include<stdio.h>                                        
/* This is an example of a do-while loop */

int main()
{
int i;

   i = 0;
   do {
      printf("The value of i is now %d\n",i);
      i = i + 1;
   } while (i < 5);
   return(0); 
}
