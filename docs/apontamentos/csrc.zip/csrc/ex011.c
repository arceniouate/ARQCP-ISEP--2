#include<stdio.h>                                        
/* This is an example of a for loop */

int main()
{
int index;

   for(index = 0;index < 6;index = index + 1)
     printf("The value of the index is %d\n",index);
 return(0);    
}
