#include <stdio.h>
#include <stdlib.h> 

int main()
{
FILE *funny;
char c;

   funny = fopen("tenlines.txt","r");

   if (funny == NULL) { 
              printf("File doesn't exist\n");
              exit(-1); } 
   else {
      do {
         c = getc(funny);    /* get one character from the file */
         putchar(c);         /* display it on the monitor       */
      } while (c != EOF);    /* repeat until EOF (end of file)  */
   }
   fclose(funny);
   return(0); 
}
