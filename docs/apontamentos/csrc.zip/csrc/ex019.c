/* The purpose of this file is to  */ 
/* introduce additional data types */

#include<stdio.h>
int main()
{
int a,b,c;            
char x,y,z;           
float num,toy,thing;  

   a = b = c = -27;
   x = y = z = 'A';
   num = toy = thing = 3.6792;

   a = y;           /* a is now 65 (character A)               */
   x = b;           /* x is now -27                            */
   num = b;         /* num will now be -27.00                  */
   a = toy;         /* a will now be 3                         */
   return(0); 
}
