#include <stdio.h>
#include <stdlib.h>

int main()
{
int index;

   for (index = 0;index < 6;index++) {
      printf("This line goes to the standard output.\n");
      fprintf(stderr,"This line goes to the error device.\n");
   }
   exit(4);  /* This can be tested with the 
                unix command line
                ./ex047 >lixo ; echo $?  */
}
