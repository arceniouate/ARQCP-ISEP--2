#include<stdio.h>
/* This is an example of a "while" loop */

int main()
{
int count;

   count = 0;
   while (count < 6) {
      printf("The value of count is %d\n",count);
      count = count + 1;
   }
   return(0);
}
