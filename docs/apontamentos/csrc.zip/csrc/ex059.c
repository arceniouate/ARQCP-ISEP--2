#include <stdio.h>                                          
int main()
{
union {
   short int value;     /* This is the first part of the union */
   struct {
      char first;   /* These two values are the second     */
      char second;
   } half;
} number;

long index;

   for (index = 12;index < 30000;index += 1000) {
      number.value = index;
      printf("%8x %6x %6x\n",number.value, number.half.first,
              number.half.second);
   }
  return(0);  
}
