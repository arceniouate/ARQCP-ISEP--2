#include<stdio.h>                                          
int sum; /* This is a global variable */

void header(); 
void square( int number);    /* function prototype */  
void ending(); 


int main()
{
int index;

   header();        /* This calls the function named header */
   for (index = 1;index <= 7;index++)
     square(index); /* This calls the square function */
   ending();        /* This calls the ending function */
   return(0); 
}

void header()        /* This is the function named header */
{
   sum = 0;     /* Initialize the variable "sum" */
   printf("This is the header for the square program\n\n");
}

void square( int number)   /* This is the square function */
{
int numsq;

   numsq = number * number;  /* This produces the square */
   sum += numsq;
   printf("The square of %d is %d\n",number,numsq);
}

void ending()   /* This is the ending function */
{
   printf("\nThe sum of the squares is %d\n",sum);
}
