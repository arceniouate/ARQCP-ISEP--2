#include <stdio.h>
#include <string.h> 

int main()
{
FILE *fp;
char stuff[25];
int index;

   fp = fopen("tenlines.txt","w");   /* open for writing */
   strcpy(stuff,"This is an example line.");

   for (index = 1;index <= 10;index++)
      fprintf(fp,"%s  Line number %d\n",stuff,index);

   fclose(fp);    /* close the file before ending program */
   return(0); 
}
