#ifndef ASM_H 
#define ASM_H 
void upper1(char *str);
#endif 

