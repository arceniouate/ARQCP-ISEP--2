#ifndef ASM_H 
#define ASM_H 
int sum_even( int *p , int num ); 
#endif 

