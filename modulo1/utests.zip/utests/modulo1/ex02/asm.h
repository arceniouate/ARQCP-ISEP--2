#ifndef ASM_H 
#define ASM_H 
void copy_vec(int *vec1, int *vec2, int n); 
#endif 

