#ifndef ASM_H 
#define ASM_H 
void  array_sort2(int * vec , int n ); 
#endif 

