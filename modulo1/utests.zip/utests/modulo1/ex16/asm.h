#ifndef ASM_H 
#define ASM_H 
char* where_exists(char* str1, char* str2); 
#endif 

