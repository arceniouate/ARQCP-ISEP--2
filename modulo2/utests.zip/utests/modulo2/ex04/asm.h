 #ifndef ASM_H
  #define ASM_H
  int sum_v2(void);
  int sum_v3(void); 
  extern int op3; 
  extern int op4; 
  
#endif
