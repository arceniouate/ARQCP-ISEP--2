 #ifndef ASM_H
  #define ASM_H
  short swapBytes(void);
#endif
